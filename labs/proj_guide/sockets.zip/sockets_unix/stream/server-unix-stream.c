#include <sys/un.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdlib.h>
#include <sys/types.h>
#include <stdio.h>


int main(){
	int sock_fd, new_sock;
	char buffer[100];
	
	struct sockaddr_un addr, client_addr;
	int addr_len; 

	unlink("/tmp/sock_1");


	sock_fd = socket(AF_UNIX, SOCK_STREAM, 0);
	perror("socket ");
	if(sock_fd == -1){
		exit(-1);
	}
	addr.sun_family = AF_UNIX;
	strcpy(addr.sun_path, "/tmp/sock_1");	
	
	bind(sock_fd, (struct sockaddr *)  &addr, sizeof(addr));
	perror("bind");
	
	
	if( listen(sock_fd, 10) == -1){
		perror("listen ");
		exit(-1);
	}
	
	while(1){
		new_sock = accept(sock_fd, NULL, NULL);
		perror("accept");


		read(new_sock, buffer, 100);
		printf("read message %s\n", buffer);


		read(new_sock, buffer, 100);
		printf("read message %s\n", buffer);
		
		

		strcpy(buffer, "444444444444");
		send(new_sock, buffer, strlen(buffer) +1, 0);
		perror("sendto");
		printf("message sent: %s\n", buffer);
		close(new_sock);
		
	}
	

	exit(0);
	
}
