#include <sys/un.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdlib.h>
#include <sys/types.h>
#include <stdio.h>


int main(){
	int sock_fd;
	char buffer[100];
	
	struct sockaddr_un addr, client_addr;
	int addr_len;

	
	unlink("/tmp/sock_1");

	sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
	perror("socket ");
	if(sock_fd == -1){
		exit(-1);
	}
	addr.sun_family = AF_UNIX;
	strcpy(addr.sun_path, "/tmp/sock_1");	
	
	bind(sock_fd, (struct sockaddr *)  &addr, sizeof(addr));
	perror("bind");
	
	read(sock_fd, buffer, 100);
	printf("read message %s\n", buffer);

	read(sock_fd, buffer, 100);
	printf("read message %s\n", buffer);

	
	recv(sock_fd, buffer, 100, 0);
	printf("recv message %s\n", buffer);

	recvfrom(sock_fd, buffer, 100, 0, (struct sockaddr *)&client_addr, &addr_len);
	printf("recv message %s\n", buffer);
	
	printf("client address %d %s\n", client_addr.sun_family, client_addr.sun_path);
	strcpy(buffer, "55555555555");
	sendto(sock_fd, buffer, strlen(buffer) +1, 0, ( struct sockaddr *) &client_addr, sizeof(client_addr));
		

	exit(0);
	
}
