#include <sys/un.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdlib.h>
#include <sys/types.h>
#include <stdio.h>
 #include <errno.h>

#include <arpa/inet.h>

int main(){
	int sock_fd;
	char buffer[100];
	
	struct sockaddr_in server_addr, client_addr;

	sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
	perror("socket ");
	if(sock_fd == -1){
		exit(-1);
	}
	
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(3000);		/* nmero de porto */
	inet_aton("146.193.41.13", & server_addr.sin_addr);	/* endereo IP */

/* this is required for the server to reply */

	client_addr.sin_family = AF_INET;
	client_addr.sin_port = htons(3001);		/* numero de porto */
	inet_aton("146.193.41.13", & client_addr.sin_addr);	/* endereco IP */
	bind(sock_fd, (struct sockaddr *)  &client_addr, sizeof(client_addr));
	perror("bind");


	strcpy(buffer, "111111111111");
	sendto(sock_fd, buffer, strlen(buffer) +1, 0, ( struct sockaddr *) &server_addr, sizeof(server_addr));
	perror("sendto");
	printf("message sent: %s\n", buffer);

	strcpy(buffer, "222222222222");
	sendto(sock_fd, buffer, strlen(buffer) +1, 0, ( struct sockaddr *) &server_addr, sizeof(server_addr));
	perror("sendto");
	printf("message sent: %s\n", buffer);

	strcpy(buffer, "333333333333");
	sendto(sock_fd, buffer, strlen(buffer) +1, 0, ( struct sockaddr *) &server_addr, sizeof(server_addr));
	perror("sendto");
	printf("message sent: %s\n", buffer);




	strcpy(buffer, "444444444444");
	sendto(sock_fd, buffer, strlen(buffer) +1, 0, ( struct sockaddr *) &server_addr, sizeof(server_addr));
	perror("sendto");
	printf("message sent: %s\n", buffer);

	read(sock_fd, buffer, 100);
	printf("read message %s\n", buffer);
					
	unlink("/tmp/sock_1");
	exit(0);
	
}
