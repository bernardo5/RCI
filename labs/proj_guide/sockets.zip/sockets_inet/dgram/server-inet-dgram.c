#include <sys/un.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdlib.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
     #include <sys/types.h>
     #include <sys/uio.h>
     #include <unistd.h>
#include <arpa/inet.h>     


int main(){
	int sock_fd;
	char buffer[100];
	
	struct sockaddr_in addr, client_addr;
	int addr_len;
	sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
	perror("socket ");
	if(sock_fd == -1){
		exit(-1);
	}
	addr.sin_family = AF_INET;
	addr.sin_port = htons(3000);		/* n�mero de porto */
	//inet_aton("146.193.41.15", & addr.sin_addr);	/* endere�o IP */
    addr.sin_addr.s_addr = INADDR_ANY;
	
	bind(sock_fd, (struct sockaddr *)  &addr, sizeof(addr));
	perror("bind");
	
	read(sock_fd, buffer, 100);
	printf("read message %s\n", buffer);

	read(sock_fd, buffer, 100);
	printf("read message %s\n", buffer);

	
	recv(sock_fd, buffer, 100, 0);
	printf("recv message %s\n", buffer);

	recvfrom(sock_fd, buffer, 100, 0, (struct sockaddr *)&client_addr, &addr_len);
	printf("recv message %s\n", buffer);
	
	printf("client address %d %s:%d\n", client_addr.sin_family, inet_ntoa(client_addr.sin_addr),ntohs(client_addr.sin_port));
	strcpy(buffer, "55555555555");
	sendto(sock_fd, buffer, strlen(buffer) +1, 0, ( struct sockaddr *) &client_addr, sizeof(client_addr));
		
	
	unlink("/tmp/sock_1");
	exit(0);
	
}
