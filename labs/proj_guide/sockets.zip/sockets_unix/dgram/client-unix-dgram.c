#include <sys/un.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdlib.h>
#include <sys/types.h>
#include <stdio.h>
 #include <errno.h>

int main(){
	int sock_fd;
	char buffer[100];
	
	struct sockaddr_un server_addr, client_addr;

	sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
	perror("socket ");
	if(sock_fd == -1){
		exit(-1);
	}
	server_addr.sun_family = AF_UNIX;
	strcpy(server_addr.sun_path, "/tmp/sock_1");	

	strcpy(buffer, "111111111111");
	sendto(sock_fd, buffer, strlen(buffer) +1, 0, ( struct sockaddr *) &server_addr, sizeof(server_addr));
	perror("sendto");
	printf("message sent: %s\n", buffer);

	strcpy(buffer, "222222222222");
	sendto(sock_fd, buffer, strlen(buffer) +1, 0, ( struct sockaddr *) &server_addr, sizeof(server_addr));
	perror("sendto");
	printf("message sent: %s\n", buffer);

	strcpy(buffer, "333333333333");
	sendto(sock_fd, buffer, strlen(buffer) +1, 0, ( struct sockaddr *) &server_addr, sizeof(server_addr));
	perror("sendto");
	printf("message sent: %s\n", buffer);

/*
 * this code should be uncomented if we need an aswerer from the server
	unlink("/tmp/sock_2");
  	client_addr.sun_family = AF_UNIX;
	strcpy(client_addr.sun_path, "/tmp/sock_2");	
	bind(sock_fd, (struct sockaddr *)  &client_addr, sizeof(client_addr));

*/

	strcpy(buffer, "444444444444");
	sendto(sock_fd, buffer, strlen(buffer) +1, 0, ( struct sockaddr *) &server_addr, sizeof(server_addr));
	perror("sendto");
	printf("message sent: %s\n", buffer);

	read(sock_fd, buffer, 100);
	printf("read message %s\n", buffer);
					

	exit(0);
	
}
