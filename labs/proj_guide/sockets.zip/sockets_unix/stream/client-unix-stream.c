#include <sys/un.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdlib.h>
#include <sys/types.h>
#include <stdio.h>
 #include <errno.h>

int main(){
	int sock_fd;
	char buffer[100];
	
	struct sockaddr_un server_addr, client_addr;

	sock_fd = socket(AF_UNIX, SOCK_STREAM, 0);
	perror("socket ");
	if(sock_fd == -1){
		exit(-1);
	}
	server_addr.sun_family = AF_UNIX;
	strcpy(server_addr.sun_path, "/tmp/sock_1");	

	if( connect(sock_fd, ( struct sockaddr *) &server_addr, sizeof(server_addr)) == -1){
		perror("connect ");
		exit(-1);
	}
	
	strcpy(buffer, "111111111111");
	send(sock_fd, buffer, strlen(buffer) +1, 0);
	perror("send");
	printf("message sent: %s\n", buffer);

	printf("press enter to continue: ");
	getchar();
	
	strcpy(buffer, "222222222222");
	send(sock_fd, buffer, strlen(buffer) +1, 0);
	perror("sendto");
	printf("message sent: %s\n", buffer);


	printf("press enter to continue: ");
	getchar();


	read(sock_fd, buffer, 100);
	printf("read message %s\n", buffer);
					
	exit(0);
	
}
